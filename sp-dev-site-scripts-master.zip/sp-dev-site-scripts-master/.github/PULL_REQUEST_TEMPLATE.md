| Q               | A
| --------------- | ---
| Bug fix?        | no - yes?
| New sample?      | no - yes?
| Related issues?  | fixes #X, partially #Y, mentioned in #Z

#### What's in this Pull Request?

Please describe the changes in this PR. Sample description or details around bugs which are being fixed.


#### Guidance
*You can delete this section when you are submitting the pull request.* 
* *Please update this PR information accordingly. We'll use this as part of our release notes in monthly communications.*
* *Please target your PR to 'master' branch.*

Thanks for your contribution! Sharing is caring.