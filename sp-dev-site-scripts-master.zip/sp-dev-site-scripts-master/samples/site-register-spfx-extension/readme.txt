Use the associateExtension action to register a deployed SharePoint Framework extension from the tenant app catalog.

For more details on how to create and configure a SharePoint Framework extension, check out: Overview of SharePoint Framework Extensions (https://docs.microsoft.com/en-us/sharepoint/dev/spfx/extensions/overview-extensions).

