# SharePoint Site Script samples

Samples for the SharePoint Site Script feature to demonstrate different capabilities and possibilities.

Each sample has its own dedicated readme file with a screenshot to show the result of the sample applied to a SharePoint site.
