# title of the sample

## Summary
Short summary on functionality and used technologies.

[picture of the provisioned site]

## Sample

Solution|Author(s)
--------|---------
folder-name | Author name and company details

## Version history

Version|Date|Comments
-------|----|--------
1.0|August 29, 2025|Initial release

## Disclaimer
**THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.**

---

## Additional notes
Any potential additional notes to get included in the readme around the sample with additional pictures etc.

- topic 1
- topic 2
- topic 3

<img src="https://telemetry.sharepointpnp.com/sp-dev-site-scripts/samples/readme-template" />