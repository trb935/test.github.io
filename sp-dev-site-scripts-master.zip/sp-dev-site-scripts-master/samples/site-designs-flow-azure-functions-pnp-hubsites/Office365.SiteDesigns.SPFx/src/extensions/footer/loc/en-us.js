define([], function() {
  return {
    "Title": "FooterApplicationCustomizer"
  }
});