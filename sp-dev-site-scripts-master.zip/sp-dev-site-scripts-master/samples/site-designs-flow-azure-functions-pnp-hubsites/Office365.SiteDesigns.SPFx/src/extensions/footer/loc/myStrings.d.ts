declare interface IFooterApplicationCustomizerStrings {
  Title: string;
}

declare module 'FooterApplicationCustomizerStrings' {
  const strings: IFooterApplicationCustomizerStrings;
  export = strings;
}
